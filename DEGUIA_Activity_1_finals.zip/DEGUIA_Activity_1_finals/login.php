<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_SESSION["user"]) && $_POST["username"] === $_SESSION["user"]["username"] && password_verify($_POST["password"], $_SESSION["user"]["password"])) {
        $_SESSION["logged_in"] = true;
        header("Location: Home.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<head>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <form method="POST" action="">
        <h1>LOG-IN!</h1>
        <div>
            <label>Username</label><br>
            <input type="text" name="username" required><br>
            <label>Password</label><br>
            <input type="password" name="password" required><br>
        </div>
        <button type="submit">Login</button>
        <a href="sign-up.php">Don't have an account?</a>
    </form>
</body>
</html>
