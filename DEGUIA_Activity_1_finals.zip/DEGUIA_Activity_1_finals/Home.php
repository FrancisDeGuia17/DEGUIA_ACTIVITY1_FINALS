<?php
session_start();
if (!isset($_SESSION["logged_in"])) {
    header("Location: login.php");
    exit;
}

$user = $_SESSION["user"];

if (isset($_POST["logout"])) {
    session_destroy();
    header("Location: login.php");
    exit;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="style.css">
    <title>Dashboard</title>
</head>
<body>
    <form method="POST">
        <button type="submit" name="logout">Logout</button>
    </form>
</body>
</html>
