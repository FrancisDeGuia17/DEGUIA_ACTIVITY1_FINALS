<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $_SESSION["user"] = [
        "name" => $_POST["name"],
        "username" => $_POST["username"],
        "age" => $_POST["age"],
        "email" => $_POST["email"],
        "password" => password_hash($_POST["password"], PASSWORD_DEFAULT)
    ];
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="style.css">
    <title>Sign Up</title>
</head>
<body>
    <form method="POST" action="">
        <h1>REGISTER</h1>
        <div>
            <label>Name</label><br>
            <input type="text" name="name" required><br>
            <label>Username</label><br>
            <input type="text" name="username" required><br>
            <label>Age</label><br>
            <input type="number" name="age" required><br>
            <label>Email</label><br>
            <input type="email" name="email" required><br>
            <label>Email</label><br>
            <input type="password" name="password" required>
        </div>
        <button type="submit">Sign Up</button>
        <a href="login.php">Already have an account?</a>
    </form>
</body>
</html>
